#!/usr/bin/python
# -*- coding: utf-8 -*-

from Tkinter import * 
from tkFileDialog import *
from tkMessageBox  import *
import os, csv, sys, re
import exifread
from datetime import datetime

class APP(Tk):
	def __init__(self,parent):
		Tk.__init__(self,parent)
		self.parent = parent
		self.initialize()

	def initialize(self):
		self.grid()
		#Logo
		self.photo = PhotoImage(file="logo_edf.gif")
		self.canvas = Canvas(self,width=50, height=50)
		self.canvas.create_image(0, 0, anchor=NW, image=self.photo)
		self.canvas.grid(column=0,row=0,sticky='EW')
		#Dossier Photo
		self.dossier_photo_label=Label(self, anchor="w", text="Dossier contenant les photos à lister")
		self.dossier_photo_label.grid(column=0,row=1,sticky='EW')
		self.dossier_photo_url=StringVar()
		self.dossier_photo = Entry(self,textvariable=self.dossier_photo_url)
		self.dossier_photo.grid(column=1,row=1,sticky='EW')
		self.dossier_photo_boutton = Button(text=' ... ',command= lambda: self.Get_file(self.dossier_photo_url,"folder") )
		self.dossier_photo_boutton.grid(column=2,row=1,sticky='EW')
		#Bouton Lister
		self.bouton_verifier=Button(self, text="Lister les photos", command=self.lister_photos)
		self.bouton_verifier.grid(column=0,row=2,sticky='EW')
		#Bouton quitter
		self.bouton_quitter=Button(self, text="Quitter", command=self.quit)
		self.bouton_quitter.grid(column=1,row=2,sticky='EW')
	
	def Get_file(self,widget,type):
		if type=="file":
			filepath = askopenfilename(title="Choisir un fichier",filetypes=[('CONFIG','.py.conf')])
		else:
			filepath = askdirectory(title="Choisir un dossier")
		widget.set(filepath)
	
	def _get_if_exist(self,data, key):
		if key in data:
			return data[key]
		return None
	
	def _convert_to_degress(self,value):
		"""
		Helper function to convert the GPS coordinates stored in the EXIF to degress in float format
		:param value:
		:type value: exifread.utils.Ratio
		:rtype: float
		"""
		d = float(value.values[0].num) / float(value.values[0].den)
		m = float(value.values[1].num) / float(value.values[1].den)
		s = float(value.values[2].num) / float(value.values[2].den)
		return d + (m / 60.0) + (s / 3600.0)

	def get_exif_location(self,exif_data):
		"""
		Returns the latitude and longitude, if available, from the provided exif_data (obtained through get_exif_data above)
		"""
		lat = None
		lon = None
		gps_latitude = self._get_if_exist(exif_data, 'GPS GPSLatitude')
		gps_latitude_ref = self._get_if_exist(exif_data, 'GPS GPSLatitudeRef')
		gps_longitude = self._get_if_exist(exif_data, 'GPS GPSLongitude')
		gps_longitude_ref = self._get_if_exist(exif_data, 'GPS GPSLongitudeRef')
		try:
			if gps_latitude and gps_latitude_ref and gps_longitude and gps_longitude_ref:
				lat = self._convert_to_degress(gps_latitude)
				if gps_latitude_ref.values[0] != 'N':
					lat = 0 - lat
				lon = self._convert_to_degress(gps_longitude)
				if gps_longitude_ref.values[0] != 'E':
					lon = 0 - lon
			return lat, lon
		except:
			return None,None
	
	def lister_photos(self):
		try:
			dir=unicode(self.dossier_photo.get(),sys.getfilesystemencoding())
		except:
			dir=self.dossier_photo.get()
		if len(dir)>0:
			photos=[u"%s"%f for f in os.listdir(dir) if os.path.isfile(os.path.join(dir, f)) and re.match(".*(JPG|GIF|PNG)",f,re.IGNORECASE)]
			if len(photos)>0:
				images=[]
				for file in photos:
					print file.encode(sys.getfilesystemencoding())
					tags=exifread.process_file(open(os.path.join(dir,file),'rb'), details=False)
					lat, lon = self.get_exif_location(tags)
					date=self._get_if_exist(tags, 'EXIF DateTimeOriginal')
					if date:
						date=date.values
						try:
							d = datetime.strptime(date, '%Y:%m:%d %H:%M:%S')
							date = d.strftime('%d/%m/%Y')
						except:
							print "format date non transformé"
					images.append([file.encode("latin-1"),date,lat,lon])
				#print images
				#Export LOG
				f= asksaveasfile(title="Sauvegarder la liste des photos",mode='wb', defaultextension=[("csv",".csv")], filetypes=[("csv",".csv")])
				if f is None:
					return
				reader=csv.writer(f,delimiter=";")
				reader.writerow([u"Photo",u"DATE",u"LAT",u"LON"])
				for row in images:
					reader.writerow(row)
				del reader
				showinfo(u"Terminé",u"Analyse terminée")
			else:
				showerror("Erreur", "Aucune photo trouvée dans le dossier (jpg,gif,png)")
		else:
			showerror("Erreur", "Saisir un dossier valide")
		#except:
		#	showerror("Erreur",u"Impossible de lire le dossier photo")
		#	return False
		
if __name__ == "__main__":
	app = APP(None)
	app.title('Lister photos repertoire - EDF DIPDE V1.0')
	app.mainloop()