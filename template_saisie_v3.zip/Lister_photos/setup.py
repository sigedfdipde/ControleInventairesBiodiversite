# setup.py
from distutils.core import setup
import py2exe

setup(windows=["Lister_Photos.py"]) 